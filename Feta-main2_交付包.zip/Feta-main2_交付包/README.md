# Feta-main2 补充交付包

> 本包用于补充 Feta-main2.zip 中缺失的模型权重与脚本，使 pipeline 可端到端运行。

## 文件清单

```
Feta-main2_交付包/
├── models/risk_classifier/          ← 风险四分类模型权重（risk_model.py 加载）
│   ├── risk_tfidf_vec.joblib          TF-IDF 向量化器（英文，10 万词表）
│   ├── risk_logreg.joblib             LogReg 分类器（Normal/Anxiety/Depression/Suicidal）
│   ├── stressor_tfidf_vec.joblib      压力源向量化器（备用）
│   └── stressor_logreg.joblib         压力源分类器（备用）
├── scripts/                         ← 修正后的构建/实验脚本
│   ├── build_intervention_pool.py     embedding 编码去掉 issue 前缀（与 classifier 对齐）
│   ├── compare_backends.py            查询 prompt 去掉 issue 前缀 + 池子加载对齐
│   └── make_demo_pool.py              演示内容从中文改为英文
├── data/
│   └── interventions.csv              演示用干预池（14 条英文，可直接跑 pipeline）
└── README.md
```

## 使用步骤

### 1. 放置文件

将本包内容**合并**到你已有的 Feta-main/ 目录中（保持目录结构不变）：

```bash
# 从本包根目录复制（Feta-main2_交付包/ 下的内容 → 你的 Feta-main/）
cp -r models/risk_classifier/  <你的Feta-main>/models/
cp scripts/*.py                <你的Feta-main>/scripts/
cp data/interventions.csv      <你的Feta-main>/data/
```

### 2. 安装依赖

```bash
cd <你的Feta-main>
uv sync
# 新增依赖：scikit-learn, joblib（uv.lock 已包含）
```

### 3. 下载句向量模型（如尚未下载）

```bash
uv run python scripts/download_model.py
# 下载到 models/all-MiniLM-L6-v2/（~90MB，从 ModelScope 下载）
```

### 4. 运行 pipeline

```bash
# 快速验证（使用 data/interventions.csv 演示池）
uv run python src/pipeline.py

# 推荐模块独立测试
uv run python src/recommender.py
```

### 5. 构建全量干预池（可选）

如需从 Sentiment140 构建完整干预池（需先下载 Sentiment140 数据集放到 `data/training.1600000.processed.noemoticon.csv/`）：

```bash
uv run python scripts/build_intervention_pool.py --backend auto
```

## 关键变更说明

| 变更 | 说明 |
|---|---|
| 模型路径 | `建模/` → `models/risk_classifier/`，risk_model.py 自动加载 |
| 风险等级 | 旧 Level_1~Suicide → 新 Normal/Anxiety/Depression/Suicidal |
| embedding 编码 | 池子与查询均**不带** issue 前缀，与 classifier.embedding_prompt 对齐 |
| 自动检测 | classifier 不再需要 config 切换 backend，文本含拉丁字母 + 模型存在 → 自动走模型 |
| 中文输入 | 自动走关键词规则（无拉丁字母检测），不会触发 TF-IDF 零向量问题 |

## 验证

运行 pipeline 后应看到：
- 英文输入 → `risk_source=model`（模型分类）
- 中文输入 → `risk_source=keyword`（关键词规则）
- 自杀关键词 → `risk_level=Suicidal` + `SUCCESS_WITH_REFERRAL`
